import './App.css';
import MoreForm from './components/MoreForm';

function App() {
  return (
    <div className="App">

      <MoreForm />

    </div>
  );
}

export default App;
