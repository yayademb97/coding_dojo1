import React, { Component } from 'react'

class SomeClassComponent extends Component {
    render() {
        return (
            <div>SomeClassComponent
                <p>Now It's not easy life with MERN Stack</p></div>
        )
    }
}
export default SomeClassComponent;
