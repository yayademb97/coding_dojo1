import './App.css';
import SomeClassComponent from './components/SomeClassComponent';
function App() {
  return (
    <div className="App">
      <h1>First React page rendering...</h1>
      <SomeClassComponent />
    </div>
  );
}

export default App;
