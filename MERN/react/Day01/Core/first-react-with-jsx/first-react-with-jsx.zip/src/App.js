import './App.css';
import MyNewComponent from './components/MyNewComponent;'

function App() {
  return (
    <div className="App">
      <MyNewComponent  />
    </div>
  );
}

export default App;
