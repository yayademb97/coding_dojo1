import './App.css';
import Tabs from './components/TabsComponent';

function App() {
  return (
    <div className="App">
      <Tabs />

    </div>
  );
}

export default App;
