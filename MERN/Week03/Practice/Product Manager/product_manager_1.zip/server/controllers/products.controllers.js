// FULL CRUD

const product = require("../models/products.models")

// READ ALL
module.exports.findAllProduct = (request, response) =>{
product.find()
.then((allDaProduct)=>{
    response.json(allDaProduct) // []
})
.catch((err)=>{ response.json({message: "Something went wrong", error: err})})
}

// READ ONE
module.exports.findOneProduct = (request, response) =>{
    product.findOne({_id: request.params.id})
    .then((oneProduct)=>{response.json(oneProduct)})
    .catch((err)=>{ response.json({message: "Something went wrong", error: err})})
}

// CREATE
module.exports.addNewProduct = (request, response) =>{
    product.create(request.body)
    .then( (newlyCreatedproduct)=>{response.json(newlyCreatedproduct._id)})
    .catch((err)=>{response.json({ message: 'Something went wrong', error: err })})
}

// UPDATE 
module.exports.updateProduct = (request, response) =>{
    product.findOneAndUpdate({_id: request.params.id}, request.body, {new: true, runValidators: true})
    .then((updatedProduct)=>{response.json(updatedProduct)})
    .catch((err)=>{response.json({ message: 'Something went wrong', error: err })})
}

module.exports.deleteProduct = (request, response) =>{
    product.deleteOne({_id: request.params.id})
    .then((result)=>{response.json({result})})
    .catch((err)=>{response.json({ message: 'Something went wrong', error: err })})
}