const productsController = require("../controllers/products.controllers")

// console.log(productsController);

module.exports = (app) => {
    app.get("/api/products", productsController.findAllProduct);
    app.post("/api/products", productsController.addNewProduct);   
    app.get("/api/products/:id", productsController.findOneProduct);
    app.put("/api/products/:id", productsController.updateProduct);
    app.delete("/api/products/:id", productsController.deleteProduct);
}