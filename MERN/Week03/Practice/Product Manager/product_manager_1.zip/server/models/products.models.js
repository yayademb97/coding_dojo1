const mongoose = require('mongoose');

const ProductsSchema = new mongoose.Schema({
    title:{
        type:String,
        require: [true, "Title is required"],
        minLength: [2, "Title must be least than 2 characters"]
    },
    
    price:{
        type:Number,
        require: [true, "Price is required"],
        min: [1, "Price must be at least 1"],
        max: [8, "Price must not exceed 8 numbers"]

    },

    description:{
        type:String,
        require: [true, "Description is required"],
        minLength: [8, "Description must be least than  c8haracters"]
    }
},{timestamps: true})

const Products = mongoose.model('Products', ProductsSchema);
module.export = Products;